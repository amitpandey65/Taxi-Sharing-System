from django.shortcuts import render
from .models import Trip

def movement(request):
    trips = Trip.objects.all()
    return render(request, 'movement/trip.html', {'trips': trips})
